

document.addEventListener('DOMContentLoaded', async (e) => {

alert("test")

});