

document.addEventListener('DOMContentLoaded', async (e) => {

    $(document).on("click", "#clear", function () {
        clear_forms();
    });

    $(document).on("click", "#translate", function () {
        translate_text()
    });

    $(document).on("click", "#paraphrase", function () {
        paraphrase_text()
    });

    $(document).on("click", "#suggestions li", function () {
        var get_val = $(this).find(".data").html();
        $(document).find("#source").val(get_val);
        translate_text();
    });

    $(document).on("click", ".w3-close", function () {        
        $(this).parent().hide();
    });

    $(document).on("click", "#ocr", function () {        
        $(document).find("#drop-area").show();
    });

    document.addEventListener('paste', function(event) {
        var items = (event.clipboardData || event.originalEvent.clipboardData).items;
        for (index in items) {
            var item = items[index];
            if (item.kind === 'file') {
                var blob = item.getAsFile();
                var reader = new FileReader();
                reader.onload = function(event) {
                    var img = document.getElementById('image-preview');
                    img.src = event.target.result;
                    img.style.display = 'block';
                };
                reader.readAsDataURL(blob);
            }
        }
    });

    document.getElementById('image-upload-form').addEventListener('submit', async function(event) {
        event.preventDefault();
        var formData = new FormData();
        var fileInput = document.getElementById('image-input');
        var file = fileInput.files[0];
        formData.append('image', file);
    
        const res = await fetch("http://127.0.0.1:5000/ocr", {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            console.log('Image uploaded:', data);
            // You can handle the response here, for example, display a success message
        })
        .catch(error => {
            console.error('Error uploading image:', error);
            // You can handle errors here, for example, display an error message
        });
    });

    document.getElementById('image-input').addEventListener('change', function(event) {
        var file = event.target.files[0];
        var reader = new FileReader();
        reader.onload = function(event) {
            var imagePreview = document.getElementById('image-preview');
            imagePreview.innerHTML = ''; // Clear previous preview
            var img = document.createElement('img');
            img.src = event.target.result;
            img.style.maxWidth = '300px'; // Limit image width for preview
            imagePreview.appendChild(img);
        };
        reader.readAsDataURL(file);
    });


});

image_upload=(blob)=>{



}


paraphrase_text = async () => {

    var get_lang = $(document).find("#source_lang").val();
    var text_source = $(document).find("#source");

    if (text_source.val() == "") {
        alert("Required Field - Source Text");
        text.focus();
        return;
    }

    if (get_lang == "en") {

        $(document).find("#suggestions").empty();
        $(document).find(".loader").parent().show();

        const res = await fetch("http://127.0.0.1:5000/paraphrase", {
            method: "POST",
            body: JSON.stringify({
                text: text_source.val(),
            }),
            headers: { "Content-Type": "application/json" }
        });

        const data = await res.json();  

        data['options'].forEach((option) => {
            $(document).find("#suggestions").append(`<li class='w3-display-container w3-ba'>
            <span class='data'>${option}</span>
            <span class="w3-button w3-display-right">&times;</span>
            </li>`);
        });

        $(document).find(".loader").parent().hide();

    } else {

    }

}


translate_text = async () => {

    var get_lang = $(document).find("#source_lang").val();
    var text = $(document).find("#source");
    var src, trgt;

    if (text.val() == "") {
        alert("Required Field - Source Text");
        text.focus();
        return;
    }
    
    if (get_lang == "en") {
        src = "en";
        trgt = "ja";
    } else {        
        trgt = "en";
        src = "ja";
    }

    const res = await fetch("http://127.0.0.1:5000/translate", {
        method: "POST",
        body: JSON.stringify({
            q: $(document).find("#source").val(),
            source: src,
            target: trgt,
            format: "text",
            api_key: ""
        }),
        headers: { "Content-Type": "application/json" }
    });

    const d = await res.json();
    $(document).find("#target").val(d.translatedText);

}

clear_forms = () => {
    $(document).find("#suggestions").html("");
    $(document).find("#source").val("");
    $(document).find("#target").val("");
    $(document).find("#source").focus();
}

function dragOverHandler(event) {
    event.preventDefault();
    event.dataTransfer.dropEffect = "copy";
}

function dropHandler(event) {
    event.preventDefault();
    const files = event.dataTransfer.files;
    if (files.length > 0) {
        const file = files[0];
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function() {
                const img = document.getElementById('image-preview');
                img.src = reader.result;
                img.style.display = 'block';
            }
            reader.readAsDataURL(file);
        } else {
            alert("Please drop an image file.");
        }
    }
}

function dragEnterHandler(event) {
    event.preventDefault();
    document.getElementById('drop-area').classList.add('highlight');
}

function dragLeaveHandler(event) {
    event.preventDefault();
    document.getElementById('drop-area').classList.remove('highlight');
}


